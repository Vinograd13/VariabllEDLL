<?php

/*
 *
 *  _____            _               _____           
 * / ____|          (_)             |  __ \          
 *| |  __  ___ _ __  _ ___ _   _ ___| |__) | __ ___  
 *| | |_ |/ _ \ '_ \| / __| | | / __|  ___/ '__/ _ \ 
 *| |__| |  __/ | | | \__ \ |_| \__ \ |   | | | (_) |
 * \_____|\___|_| |_|_|___/\__, |___/_|   |_|  \___/ 
 *                         __/ |                    
 *                        |___/                     
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author GenisysPro
 * @link https://github.com/GenisysPro/GenisysPro
 *
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\math\AxisAlignedBB;
use pocketmine\nbt\tag\{ByteTag, DoubleTag, CompoundTag, IntTag, StringTag, ListTag, FloatTag};
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\level\Level;
use pocketmine\entity\Wither;
use pocketmine\tile\Skull;
use pocketmine\tile\Tile;

class SkullBlock extends Flowable {

	protected $id = self::SKULL_BLOCK;

	/**
	 * SkullBlock constructor.
	 *
	 * @param int $meta
	 */
	public function __construct($meta = 0){
		$this->meta = $meta;
	}

	/**
	 * @return int
	 */
	public function getHardness(){
		return 1;
	}

	/**
	 * @return bool
	 */
	public function getName() : bool{
		return 'Mob Head';
	}

	/**
	 * @return AxisAlignedBB
	 */
	protected function recalculateBoundingBox(){
	    
		return new AxisAlignedBB(
			$this->x + 0.25,
			$this->y,
			$this->z + 0.25,
			$this->x + 0.75,
			$this->y + 0.5,
			$this->z + 0.75
		);
	}
	
	public function spawnWither(Vector3 $pos, Level $level){
        $wither = new Wither($level, new CompoundTag('', [
        'Pos' => new ListTag('Pos', [new DoubleTag('', $pos->x),new DoubleTag('', $pos->y),new DoubleTag('', $pos->z)]),
        'Motion' => new ListTag('Motion', [ new DoubleTag('', 0),new DoubleTag('', 0),new DoubleTag('', 0)]),
        'Rotation' => new ListTag('Rotation', [new FloatTag('', 90),new FloatTag('', 0)]),]));
        $wither->spawnToAll();
        return $wither;
    }
    
	public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
		if($face !== 0){
			$this->meta = $face;
			$rot = 0;
			if($face === Vector3::SIDE_UP and $player !== null){
				$rot = floor(($player->yaw * 16 / 360) + 0.5) & 0x0F;
			}
			$this->getLevel()->setBlock($block, $this, true);
			$moveMouth = false;
			if($item->getDamage() === Skull::TYPE_DRAGON){
				if(in_array($target->getId(), [Block::REDSTONE_TORCH, Block::REDSTONE_BLOCK])) $moveMouth = true;
			}
			$nbt = new CompoundTag('', [
				new StringTag('id', Tile::SKULL),
				new ByteTag('SkullType', $item->getDamage()),
				new ByteTag('Rot', $rot),
				new ByteTag('MouthMoving', (bool) $moveMouth),
				new IntTag('x', (int) $this->x),
				new IntTag('y', (int) $this->y),
				new IntTag('z', (int) $this->z)
			]);
			if($item->hasCustomName()) $nbt->CustomName = new StringTag('CustomName', $item->getCustomName());
			
			Tile::createTile('Skull', $this->getLevel(), $nbt);
			if($item->getDamage() === 1 and $player instanceof Player){
				$level = $player->getLevel();
				if($level->getBlock($target->asVector3())->getId() === 88){
					if($level->getBlock($target->asVector3()->add(1, 0, 0)) and $level->getBlock($target->asVector3()->subtract(1, 0, 0))->getId() === 88 and $level->getBlock($target->asVector3()->subtract(0, 1, 0))->getId() === 88 and $level->getTile($target->asVector3()->add(1, 1, 0)) instanceof Skull and $level->getTile($target->asVector3()->add(0, 1, 0)->subtract(1, 0, 0)) instanceof Skull){
					    
					    
						$this->spawnWither($target->asVector3(), $level);
						
						$level->setBlock($target->asVector3(), Block::get(0, 0));
						$level->setBlock($target->asVector3()->subtract(0, 1, 0), Block::get(0, 0));
						$level->setBlock($target->asVector3()->subtract(1, 0, 0), Block::get(0, 0));
						$level->setBlock($target->asVector3()->add(1, 0, 0), Block::get(0, 0));
						
						$level->setBlock($target->asVector3()->add(0, 1, 0), Block::get(0, 0));
						$level->setBlock($target->asVector3()->add(1, 1, 0), Block::get(0, 0));
						$level->setBlock($target->asVector3()->add(0, 1, 0)->subtract(1, 0, 0), Block::get(0, 0));
						return true;
					}
					if($level->getBlock($target->asVector3()->add(0, 0, 1)) and $level->getBlock($target->asVector3()->subtract(0, 0, 1))->getId() === 88 and $level->getBlock($target->asVector3()->subtract(0, 1, 0))->getId() === 88 and $level->getTile($target->asVector3()->add(0, 1, 1)) instanceof Skull and $level->getTile($target->asVector3()->add(0, 1, 0)->subtract(0, 0, 1)) instanceof Skull){
					    
						$this->spawnWither($target->asVector3(), $level);
						
						$level->setBlock($target->asVector3(), Block::get(0, 0));
						$level->setBlock($target->asVector3()->subtract(0, 1, 0), Block::get(0, 0));
						$level->setBlock($target->asVector3()->subtract(0, 0, 1), Block::get(0, 0));
						$level->setBlock($target->asVector3()->add(0, 0, 1), Block::get(0, 0));
						
						$level->setBlock($target->asVector3()->add(0, 1, 0), Block::get(0, 0));
						$level->setBlock($target->asVector3()->add(0, 1, 1), Block::get(0, 0));
						$level->setBlock($target->asVector3()->add(0, 1, 0)->subtract(0, 0, 1), Block::get(0, 0));
						return true;
					}
				}
			}
			return true;
		}

		return false;
	}

	/**
	 * @param Item $item
	 *
	 * @return array
	 */
	public function getDrops(Item $item) : array{
		$tile = $this->level->getTile($this);
		if($tile instanceof Skull){
			return [
				[Item::MOB_HEAD, $tile->getType(), 1]
			];
		}
		return [];
	}
}
