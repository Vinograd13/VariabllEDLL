<?php

namespace pocketmine\entity;

use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\level\particle\SnowballPoofParticle;
use pocketmine\network\mcpe\protocol\AddEntityPacket;
use pocketmine\Player;

class LlamaSpit extends Throwable{
 const NETWORK_ID = 102;

 protected $damage = 0.5;

 protected function onHit(ProjectileHitEvent $event) : void{
  for($i = 0; $i < 6; ++$i){
  }
 }

 /**
  * @param Player $player
  */
 public function spawnTo(Player $player){
  $pk = new AddEntityPacket();
  $pk->type = LlamaSpit::NETWORK_ID;
  $pk->entityRuntimeId = $this->getId();
  $pk->x = $this->x;
  $pk->y = $this->y;
  $pk->z = $this->z;
  $pk->speedX = $this->motion->x;
  $pk->speedY = $this->motion->y;
  $pk->speedZ = $this->motion->z;
  $pk->metadata = $this->dataProperties;
  $player->dataPacket($pk);

  parent::spawnTo($player);
 }
}