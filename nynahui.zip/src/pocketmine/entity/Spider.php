<?php

/*
 *  ___                                 _____                        
 * (  _`\                              (_   _)                       
 * | (_(_)_ __   _    ____    __    ___  | |   __     _ _   ___ ___  
 * |  _) ( '__)/'_`\ (_  ,) /'__`\/' _ `\| | /'__`\ /'_` )/' _ ` _ `\
 * | |   | |  ( (_) ) /'/_ (  ___/| ( ) || |(  ___/( (_| || ( ) ( ) |
 * (_)   (_)  `\___/'(____)`\____)(_) (_)(_)`\____)`\__,_)(_) (_) (_)
 *
 *
 * @link https://vk.com/frozencore_team
 *
 *
*/

namespace pocketmine\entity;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\Item as ItemItem;
use pocketmine\network\mcpe\protocol\AddEntityPacket;
use pocketmine\Player;

class Spider extends Monster{
	const NETWORK_ID = 35;
	public $width = 1.4;
	public $height = 0.9;

	public $dropExp = [5, 5];

	/**
	 * @return string
	 */
	public function getName() : string{
		return "Spider";
	}

	/**
	 * @param Player $player
	 */
	public function spawnTo(Player $player){
		$pk = new AddEntityPacket();
		$pk->entityRuntimeId = $this->getId();
		$pk->type = Spider::NETWORK_ID;
		$pk->x = $this->x;
		$pk->y = $this->y;
		$pk->z = $this->z;
		$pk->speedX = $this->motion->x;
		$pk->speedY = $this->motion->y;
		$pk->speedZ = $this->motion->z;
		$pk->yaw = $this->yaw;
		$pk->pitch = $this->pitch;
		$pk->metadata = $this->dataProperties;
		$player->dataPacket($pk);


		parent::spawnTo($player);
	}

	/**
	 * @return array
	 */
	public function getDrops(){
		$drops = [ItemItem::get(ItemItem::STRING, 0, 1)];
		if($this->lastDamageCause instanceof EntityDamageByEntityEvent and $this->lastDamageCause->getEntity() instanceof Player){
			if(mt_rand(0, 199) < 5){
				switch(mt_rand(0, 2)){
					case 0:
						$drops[] = ItemItem::get(ItemItem::IRON_INGOT, 0, 1);
						break;
					case 1:
						$drops[] = ItemItem::get(ItemItem::CARROT, 0, 1);
						break;
					case 2:
						$drops[] = ItemItem::get(ItemItem::POTATO, 0, 1);
						break;
				}
			}
		}
		return $drops;
	}
}