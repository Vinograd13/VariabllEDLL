<?php

namespace debug\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use debug\Loader;

class DebugCommand extends Command{

	public function __construct($name, $description, Loader $api){
		parent::__construct("debug", "режим отладки");
		$this->api = $api;
	}

	public function execute(CommandSender $sender, $commandLabel, array $args){
		if ($sender instanceof Player){
		    return false;
		}
		if (!isset($args[0])){
		    return false;
		}
		if ($args[0] === "on"){
			$this->api->debugStatus = true;
			return true;
		} else if ($args[0] === "off"){
			$this->api->debugStatus = false;
			return true;
		}
		return false;
	}
}