<?php

namespace debug\handler;

use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\MovePlayerPacket;
use pocketmine\network\mcpe\protocol\ProtocolInfo;
use pocketmine\network\mcpe\protocol\InteractPacket;
use debug\Loader;

class DebugHandler implements Listener{

    private Loader $api;
    
	public function __construct(Loader $api){
		$this->api = $api;
	}

	public function handleDataPacketReceive(DataPacketReceiveEvent $e){
		$p = $e->getPlayer();
		if ($this->api->debugStatus === true){
	    	$packets = [ProtocolInfo::INTERACT_PACKET, ProtocolInfo::PLAYER_ACTION_PACKET, ProtocolInfo::MOVE_PLAYER_PACKET, ProtocolInfo::LEVEL_SOUND_EVENT_PACKET, ProtocolInfo::ANIMATE_PACKET];
	     	if(in_array($e->getPacket()::NETWORK_ID, $packets)){
		         return;
	    	}
	    	$nick = strtolower($p->getName());
	    	$ip = $p->getAddress();
	    	$packet = print_r($e->getPacket(), true);
		    if (!is_null($this->api->debugger)) {
				$this->api->debugger->putPacket($nick, $ip, $packet);
			}
		}
	}
}